/**
 * Lost In Jungle for js13k 2017
 * @id splash.js
 *     splash screen to show company logo
 * @author Zendrael
 * @date 13/08/2017
 */

/**
 * Splash class
 *
 * @class Splash
 * @constructor
 */
splash = {
  /**
   * setup the scene
   *
   * @method init
   * @return {null}
   */
  init: function() {
    var logo = $.image($.centerX, $.centerY - 10, 'l');
    logo.anchor.x = $.anchor.CENTER;
    logo.anchor.y = $.anchor.BOTTOM;

    setTimeout(function() {
      $.goTo(load);
    }, 3000);
  },

  /**
   * update scene elements
   *
   * @method update
   * @return {null}
   */
  update: function() {}
};
//eof
