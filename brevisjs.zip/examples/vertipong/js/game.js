/**
 * Brevis.js v0.1
 * test $
 * date: 05/2017
 */

//Main
$.onReady(function() {
  //configure environment
  $.setup({
    title: "Teste Brevis",
    author: "BrevisJS",
    description: "Simple example game made with BrevisJS",
    //icons : [], //TO-DO
    width: 320, //1280,
    height: 480, //720,
    orientation: 'portrait',
    fps: 60,
    //pixelart : true, //default false
    //bgColor : '#0066cc', //default transparent
    assets: {
      //files  : ['language.json','atlas.json'], //TO-DO
      sounds: ['sounds/sfx_woop'], //sounds without extension
      images: ['images/logo.png', 'images/imagem.png', 'images/padPlayer.png', 'images/padEnemy.png', 'images/ball.png', 'images/botao.png', 'images/sprite.png']
    }
  });

  //first scene to go
  $.goTo(splash);
});

//scenes
splash = {
  init: function() {
    console.log('carregou cena splash!');

    var logo = $.image($.centerX, $.centerY, 'logo');
    logo.anchor.x = $.anchor.CENTER;
    logo.anchor.y = $.anchor.CENTER;

    setTimeout(function() {
      $.goTo(load);
    }, 3000);
  },

  update: function() {}
};

load = {
  init: function() {
    console.log('carregou cena load!');

    var loadLogo = $.image($.centerX, $.centerY, 'sprite');
    loadLogo.anchor.x = $.anchor.CENTER;
    loadLogo.anchor.y = $.anchor.BOTTOM;

    $.loadBar = '';
    $.loadContainer = '';
  },

  update: function() {
    if ($.loadComplete) $.goTo(title);
  }
};

title = {
  init: function() {
    console.log('carregou cena title!');

    this.background = $.image(0, 0, 'imagem');

    this.logo = $.image($.centerX, 100, 'logo');
    this.logo.anchor.x = $.anchor.CENTER;

    var btnPlay = $.button($.centerX, $.centerY, 'botao');
    btnPlay.anchor.x = $.anchor.CENTER;
    btnPlay.anchor.y = $.anchor.TOP;
    btnPlay.on('click', this.btnPlayClick);
  },

  update: function() {},

  btnPlayClick: function() {
    $.goTo(play);
  }
};

play = {
  init: function() {
    console.log('carregou cena play!');

    //this.background = $.image(0,0,'imagem');

    this.enemy = $.sprite($.centerX, 50, 'padEnemy', 100, 25);
    this.enemy.anchor.x = $.anchor.CENTER;
    //custom properties
    this.enemy.vx = $.rand(1,4);

    this.ball = $.sprite($.centerX, $.centerY, 'ball', 25, 25);
    this.ball.anchor.x = $.anchor.CENTER;
    this.ball.anchor.y = $.anchor.CENTER;
    //custom properties
    this.ball.vx = $.rand(5,7);
    this.ball.vy = $.rand(5,7);

    this.player = $.sprite($.centerX, $.canvas.height - 100, 'padPlayer', 100, 25);
    this.player.anchor.x = $.anchor.CENTER;
    //this.player.addAnimation('change', [0,1,2,1,0], 10);
    //custom properties
    this.player.vx = 2;

    //remove
    $.canvas.addEventListener('mousemove', function(e){
      $.currentScene.player.x = e.clientX-$.currentScene.player.width/2;
    });
    //behaviors
    //player.addBehavior($.behavior.PLATFORM);
  },

  update: function() {
    $.isColliding(this.ball, this.enemy, this.collideBall);
    $.isColliding(this.ball, this.player, this.collideBall);
    //custom functions
    this.ballMovement();
    this.enemyMovement();
    this.playerMovement();
  },

  ballMovement: function() {
    this.ball.x += this.ball.vx;
    this.ball.y += this.ball.vy;

    if (this.ball.x < 0 || this.ball.x > $.canvas.width) {
      this.ball.vx = -this.ball.vx;
    }

		if (this.ball.y < 0){
      console.log('Player point!');
      this.restart();
    }else if(this.ball.y > $.canvas.height) {
      console.log('Enemy point!');
      this.restart();
    }
  },

  enemyMovement: function() {
    if(this.ball.x < this.enemy.x){
      this.enemy.x += -this.enemy.vx;
    }else{
      this.enemy.x += this.enemy.vx;
    }
  },

  playerMovement: function() {
    //this.player.play('change');

    /*var FRICTION = 0.8;
    if (this.player.y + this.player.height < $.canvas.height && this.player.direction == 'r') {
    	this.player.y += this.player.speed * FRICTION;
    	this.player.direction = 'r';
    } else {
    	this.player.direction = 'l';
    }

    if (this.player.y >= 0 && this.player.direction == 'l') {
    	this.player.y -= this.player.speed * FRICTION;
    	this.player.direction = 'l';
    } else {
    	this.player.direction = 'r';
    }*/
  },

  collideBall : function(ball, other){
    console.log('colidiu!');
    ball.vx = ball.vx*(-1);
    ball.vy = ball.vy*(-1);
  },

  restart : function(){
    this.enemy.x = $.centerX;
    this.enemy.vx = $.rand(1,4);

    this.ball.x = $.centerX;
    this.ball.y = $.centerY;
    this.ball.vx = $.rand(5,7);
    this.ball.vy = $.rand(5,7);

    this.player.x = $.centerX;
  }
};
//eof
