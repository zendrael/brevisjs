#!/bin/bash

#Verifica se recebeu o nome do tema
if [ $# -eq 0 ]; then
	echo "Specify the origin and destination of the build!"
	echo "Example: ./build.sh origin destination"
	exit 1
fi

#directory of origin
ORIGIN=$1

if [ ! -d $ORIGIN ]; then
	echo "Origin not found!"
	exit 1
fi

#pega nome do locutor
if [ -z "$2"  ]; then
	echo "Specify a destination!"
	exit 1
fi

DESTINATION=$2

if [ ! -d $DESTINATION ]; then
	echo "Destination not found, will try to create..."
	mkdir $DESTINATION
#	exit 1
fi

echo "Minify HTML..."
###sudo npm install html-minifier -g
html-minifier --html5 \
	--remove-comments \
	--remove-attribute-quotes \
	--collapse-whitespace \
	$ORIGIN/index.min.html \
	-o $DESTINATION/index.html

echo "Minify CSS..."
###sudo npm install clean-css-cli -g
#cleancss -O 2 $ORIGIN/css/main.css -o $DESTINATION/css/main.css

echo "Joining JS files..."
mkdir $DESTINATION/js
## listar aqui na ordem em que são chamados pelo index.html
cat ../dist/brevis.min.js <(echo) \
	$ORIGIN/js/load.js <(echo) \
	$ORIGIN/js/title.js <(echo) \
	$ORIGIN/js/over.js <(echo) \
	$ORIGIN/js/play.js <(echo) \
	$ORIGIN/js/main.js <(echo) \
	> $DESTINATION/js/game.full.js

echo "Compressing JS..."
###sudo npm install uglify-js -g
#uglifyjs --compress --mangle --output $DESTINATION/js/g.js $DESTINATION/js/game.full.js
uglifyjs $DESTINATION/js/game.full.js --compress toplevel,sequences,dead_code,drop_debugger,conditionals,booleans,loops,unused,if_return,inline,join_vars,cascade,reduce_vars,drop_console \
	--mangle -o $DESTINATION/js/g.js
###sudo npm install -g google-closure-compiler-js
#google-closure-compiler-js --compilationLevel ADVANCED $DESTINATION/js/game.full.js > $DESTINATION/js/g.js
#google-closure-compiler-js $DESTINATION/js/game.full.js > $DESTINATION/js/g.js

rm $DESTINATION/js/game.full.js

echo "Optimizing images..."
###https://pngquant.org/
FILES=$ORIGIN/img/*.png
mkdir $DESTINATION/img
for f in $FILES
do
	FILE=`basename $f`
	pngquant -s1 --quality=5-50 -f $f --output $DESTINATION/img/${FILE%.*}.png
done

echo "Compressing sounds..."
cp -Rf $ORIGIN/snd $DESTINATION/snd

FILES=$ORIGIN/snd/*.wav
for f in $FILES
do
	#echo "Processing $f file..."
	FILE=`basename $f`
	sox $f -r 3000 -c 1 $DESTINATION/snd/$FILE
done

#echo "Generating OGG sounds..."
#FILES=$DESTINATION/asset/*.mp3
#for f in $FILES
#do
	#echo "Processing $f file..."
#	FILE=`basename $f`
#	sox $f $DESTINATION/asset/${FILE%.*}.ogg
#done

echo "Done!"
#eof
